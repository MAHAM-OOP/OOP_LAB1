class task2{
	public static void main(String[] args){
	
	    String name = "maham";
	    String check = "";
	   
		for (int i=name.length()-1; i>=0; i--)	
          check = check + name.charAt(i);
		
		if(name.equals(check)){
			System.out.println("this is Palindrome");
		}
		
		else{
			System.out.println("this not palindrome");
		}
}




	}
