class employee{
String name;
String empID;
double salary;

public employee(String name, String empID, double salary){
this.name=name;
this.empID=empID;
this.salary=salary;
}

public void increaseSAL(double amount){
salary += amount;
}

public void annualSAL(){

System.out.println(salary*12);
}

public void displayDetails(){
System.out.println("employes name:"+ name);
System.out.println("employes id:"+ empID);
System.out.println("salary:" + salary);
}


public static void main(String[] args){
employee e1= new employee("Maham","60f24Ari", 35000);
e1.increaseSAL(2000);
e1.displayDetails();
e1.annualSAL();
}
}
