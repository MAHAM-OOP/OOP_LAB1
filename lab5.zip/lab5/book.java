class Book{
String title;
String author;
boolean isAvailable;
public Book(String tit, String auth){
this.title=tit;
this.author=auth;
this.isAvailable=true;
}
public void borrowbook()
{
if(isAvailable)
{
isAvailable=false;
System.out.println("Book is currently unavailable");
}
else{
System.out.println("already purchased");
}
}
public void returnBook()
{
isAvailable=true;
System.out.println("Book is available");
}
public void bookStatus(){
if(isAvailable){
System.out.println("Available");
}
else{
System.out.println("Unavail");
}
}
public void displayBookDetails(){

System.out.println("Book title"+title);
System.out.println("Author's name:"+author);
System.out.println("book staus" +isAvailable);
}

public static void main(String[] args){
Book b1 = new Book("Hamlet", "William Shakespear");
b1.displayBookDetails();
b1.borrowbook();
b1.displayBookDetails();
b1.borrowbook();
b1.returnBook();
b1.displayBookDetails();
}
}
