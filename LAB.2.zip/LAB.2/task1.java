import java.util.Scanner;
class task1 {
    public static void main(String[] args) {
char consnt_arr[]={'b','c','d','f','g','h','j','k','l','m','n','p','q','r','s','t','v','w','x','y','z'};
Scanner user_inp=new Scanner(System.in);
System.out.println(" enter any character A to Z");
char input=user_inp.next().charAt(0);
boolean isConsnt=false;
for(int i=0;i<consnt_arr.length;i++){
if(user_inp==consnt_arr[i]){
isConsnt=true;
break;
}

if(isConsnt){
System.out.print("consnt");

}

else{
System.out.print("this is not consnt");
}



}


}
}