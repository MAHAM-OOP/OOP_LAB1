class task5{
public static void main(String[] args){
System.out.println("**********\n*\t*\n*\t*\n*\t*\n**********");
}
}