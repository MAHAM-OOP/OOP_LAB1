class lab1{
public static void main(String[] args){
System.out.println("/////////////////////");
System.out.print(" ");
System.out.print("Student points");
System.out.print("      ");
System.out.println("**");
System.out.println("/////////////////////");
System.out.println("Lab  Bonus  total");
System.out.println("---  ---   ---");
System.out.println("43  7     50");
System.out.println("50  8     58");
System.out.println("39  10    49");



}





}