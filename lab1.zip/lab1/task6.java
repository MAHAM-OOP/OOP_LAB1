class task6{
public static void main(String[] args){
int dollar=5;
System.out.print("value in Rs = ");
System.out.print(dollar*285);
}
}