class task3{
public static void main(String[] args){
String name="Maham";
int age=19;
double gpa=3.75;
char gender='F';
boolean foreigner=false;
System.out.println(name);
System.out.println(age);
System.out.println(gpa);
System.out.println(gender);
System.out.println(foreigner);


}
}