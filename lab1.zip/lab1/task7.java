class task7{
public static void main(String[] args){
int radius=5;
double height=5.5;

System.out.print("the volume is equal to:");
System.out.print(3.14*(5^2)*5.5);
}
}

