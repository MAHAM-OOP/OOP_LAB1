import java.util.Scanner;
public class task8{
public static void main(String[]args){
Scanner num=new Scanner(System.in);
double speed;
System.out.println("enter speed in miles:");
speed=num.nextDouble();
System.out.println("speed in km ="+ (speed*1.6));
}
}
