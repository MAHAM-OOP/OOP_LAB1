import java.util.Scanner;

public class task9 {
    public static void main(String[] args) {
        Scanner operator = new Scanner(System.in);
        System.out.println("Enter any operator (+, -, *, /):");
        char opt = operator.next().charAt(0);        
        Scanner No = new Scanner(System.in);
        System.out.println("Enter 1st number:");
        int num1 = No.nextInt();
        Scanner Number = new Scanner(System.in);
        System.out.println("Enter 2nd number:");
        int num2 = Number.nextInt();
        if (opt == '+') {
            System.out.println( + (num1 + num2));
        } else if (opt == '-') {
            System.out.println(+ (num1 - num2));
        } else if (opt == '*') {
            System.out.println(+ (num1 * num2));
        } else if (opt == '/') {
                System.out.println(+ (num1 / num2));
            }
         else {
            System.out.println("Invalid operator.");
        }
    }
}
