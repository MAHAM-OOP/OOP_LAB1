class Main {
	public static void main (String[]args) {
		FulltimeEmployee fte = new FulltimeEmployee("maham", "h3yh", 40000);
        fte.display();
        fte.CalculateSalary();
        System.out.println("Tax of Full-time-Employee: " + fte.payTax());

        ParttimeEmployee pte = new ParttimeEmployee("mamahammm", "h3h4h", 34000, 18);
        pte.display();
        pte.CalculateSalary();
        System.out.println("Tax of Part-time-Employee: " + pte.payTax()); 
	}
}