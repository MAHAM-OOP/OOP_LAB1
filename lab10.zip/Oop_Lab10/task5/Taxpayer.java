interface TaxPayer {
	abstract public double payTax();
}