abstract class Animal {
	abstract public void makeSound();
	void eat() {
		System.out.println("Animal is Eating.");
	}
}