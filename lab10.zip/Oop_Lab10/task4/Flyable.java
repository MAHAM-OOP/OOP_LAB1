interface Flyable {
	abstract public void Fly();

}