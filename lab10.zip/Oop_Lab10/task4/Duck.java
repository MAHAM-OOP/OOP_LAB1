class Duck implements Flyable, Swimmable {
	public void Fly() {
		System.out.println("Duck is flying here");
	}

	public void Swim() {
		System.out.println("Duck is swimming here.");
	}
} 