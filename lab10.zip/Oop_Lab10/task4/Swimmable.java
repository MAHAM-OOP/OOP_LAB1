interface Swimmable {
	abstract public void Swim();
}