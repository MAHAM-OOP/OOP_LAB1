class Car implements Vehicle {
	public void Start() {
		System.out.println("Car is start");
	}

	public void Stop() {
		System.out.println("Car is stop here.");
	}
}