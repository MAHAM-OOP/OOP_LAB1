interface Vehicle {
	abstract public void Start();
	abstract public void Stop();
}