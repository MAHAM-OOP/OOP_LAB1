class Bike implements Vehicle {
	public void Start() {
		System.out.println("Bike is start.");
	}

	public void Stop() {
		System.out.println("Bike is Stop.");
	}
}