abstract class Shape {
	abstract public int Area();
}