interface Printable {
	abstract public void Print();
}