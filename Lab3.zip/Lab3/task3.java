class task3{
public static void main(String[]args){
int sum=0;
int[][] matrix={12,13,15,16},{11,110,121,12},{17,18,100,21};
for(int row=0;row<3; row++){
for(int col=0;col<4;col++){
if(matrix[row][col]%2==0){
matrix[row][col]=matrix[row][col]/2;
}
System.out.println(matrix[row][col]);
}
System.out.println();
}
for(int row=0;row<3;row++){
for(int col=0;col<4;col++)
if(matrix[row][col]%2!=0){
System.out.println("ODD : " + matrix[row][col]);
}
}
}
for(int row=0;row<3;row++){
for(int col=0;col<4;col++){
if(matrix[row][col]%2==0)
sum=sum+matrix[row][col];

}
}
}
System.out.println("sum :"+ sum);
}
}